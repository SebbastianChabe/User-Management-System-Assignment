<?php include "database/db.php"; ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Management System</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 90%;
            max-width: 800px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            padding: 30px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 25px;
        }
        .user-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #f9f9f9;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: 0.3s;
        }
        .user-card:hover {
            background: #e8f0fe;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .user-info img {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #007BFF;
        }
        .user-text {
            display: flex;
            flex-direction: column;
        }
        .user-text span {
            font-size: 15px;
            color: #555;
        }
        .user-text .name {
            font-weight: bold;
            font-size: 16px;
            color: #333;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .add-btn {
            display: block;
            width: 100%;
            margin-top: 20px;
            text-align: center;
        }
        .add-btn a {
            text-decoration: none;
            background-color: #007BFF;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: bold;
            display: inline-block;
        }
        .add-btn a:hover {
            background-color: #0056b3;
        }
        .error-message {
            text-align: center;
            color: red;
            margin-bottom: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User List</h2>

        <?php
        if (isset($_GET['error']) && $_GET['error'] === 'invalid') {
            echo '<p class="error-message">⚠️ Invalid request. Please try again.</p>';
        }
        ?>

        <?php
        $result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '
                <div class="user-card">
                    <div class="user-info">
                        <img src="' . $row['image_path'] . '" alt="Profile">
                        <div class="user-text">
                            <span class="name">' . htmlspecialchars($row['name']) . '</span>
                            <span>' . htmlspecialchars($row['email']) . '</span>
                        </div>
                    </div>
                    <a href="delete_user.php?id=' . $row['id'] . '" class="delete-btn" onclick="return confirm(\'Are you sure you want to delete this user?\')">Delete</a>
                </div>';
            }
        } else {
            echo "<p style='text-align: center;'>No users found.</p>";
        }
        ?>

        <div class="add-btn">
            <a href="add_user.php">➕ Add New User</a>
        </div>
    </div>
</body>
</html>
