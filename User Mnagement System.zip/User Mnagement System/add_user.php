<?php include "database/db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <style>
        /* General Body Styling */
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f9f9f9;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        /* Form Styling */
        form {
            background-color: #fff;
            padding: 30px;
            max-width: 600px;
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-weight: 600;
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 8px;
        }

        /* Input Fields */
        input[type="text"], input[type="email"], input[type="file"] {
            width: 95%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            background-color: #f9f9f9;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="email"]:focus, input[type="file"]:focus {
            border-color: #007BFF;
            background-color: #fff;
            outline: none;
        }

        /* Button Styling */
        button {
            width: 100%;
            padding: 15px;
            background-color: #007BFF;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Link Styling */
        .back-link {
            display: inline-block;
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
            color: #007BFF;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>

    <form action="add_user.php" method="POST" enctype="multipart/form-data">
        <h2>Add New User</h2>

        <label for="name">Name</label>
        <input type="text" name="name" id="name" placeholder="Enter full name" required>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Enter email" required>

        <label for="image">Upload Profile Picture</label>
        <input type="file" name="image" id="image" accept=".jpg,.jpeg,.png" required>

        <button type="submit" name="submit">Add User</button>

        <a class="back-link" href="index.php">← Back to User List</a>
    </form>

<?php
if (isset($_POST['submit'])) {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);

    $imageName = $_FILES['image']['name'];
    $imageTmp = $_FILES['image']['tmp_name'];
    $uploadDir = "uploads/";
    $ext = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png'];

    if (in_array($ext, $allowed)) {
        $newImage = uniqid() . "." . $ext;
        $targetPath = $uploadDir . $newImage;

        if (move_uploaded_file($imageTmp, $targetPath)) {
            $sql = "INSERT INTO users (name, email, image_path) VALUES ('$name', '$email', '$targetPath')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('User added successfully!'); window.location.href='index.php';</script>";
            } else {
                echo "<script>alert('Database error.');</script>";
            }
        } else {
            echo "<script>alert('Failed to upload image.');</script>";
        }
    } else {
        echo "<script>alert('Only JPG, JPEG, and PNG files are allowed.');</script>";
    }
}
?>
</body>
</html>
