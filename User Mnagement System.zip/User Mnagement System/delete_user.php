<?php
include "database/db.php";

// Check if user ID is provided via GET
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Get image path before deleting the user
    $query = "SELECT image_path FROM users WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $imagePath = $row['image_path'];

        // Delete the record from database
        $deleteQuery = "DELETE FROM users WHERE id = $id";
        if (mysqli_query($conn, $deleteQuery)) {

            // Delete the image file if it exists
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }

            echo "<script>
                    alert('User deleted successfully!');
                    window.location.href='index.php';
                </script>";
        } else {
            echo "<script>
                    alert('Error deleting user.');
                    window.location.href='index.php';
                </script>";
        }
    } else {
        echo "<script>
                alert('User not found.');
                window.location.href='index.php';
            </script>";
    }
} else {
    echo "<script>
            alert('Invalid request.');
            window.location.href='index.php';
        </script>";
}
?>
